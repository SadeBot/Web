<!DOCTYPE html>
<html lang="en">
<head>
  <title>Administrace</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">ADMINISTRACE</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="<?php echo base_url();?>">Hlavní stránka</a></li>
      <li><a href="<?php echo base_url();?>index.php/auth/users">Správa uživatelů</a></li>
      <li><a href="<?php echo base_url();?>index.php/auth/pridaniSkoly">Přidání školy</a></li>
      <li><a href="<?php echo base_url();?>index.php/auth/pocetUchazecu">Vložit počet uchazečů</a></li>
    </ul>
  </div>
</nav>

</body>
</html>