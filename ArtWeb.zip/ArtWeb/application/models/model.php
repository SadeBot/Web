<?php

class model extends CI_Model {


    public function __construct() {
        parent::__construct();
    }

    
    public function get_cesty() {
      //  $query = $this->db->get("skola"); 
        
        
        
        $query = 

        $this->db->select('skola.id id, skola.nazev nazev, mesto.nazev nazevMesta, skola.geolat geolat, skola.geolong geolong')
        ->from('skola')
        ->join('mesto','mesto = mesto.id')
        ->get();
        return $query->result();
        
    }
     public function get_lety() {
        $query = $this->db->get("lety"); 
        return $query->result(); 
    }
    public function get_denik() {
        $query = $this->db->get("denik"); 
        return $query->result(); 
    }
    function saverecords($id,$cil,$oddo,$dopravniprostredek)
	{
	$query="INSERT INTO cesty (id, cil, oddo, dopravniprostredek) VALUES ('$id', '$cil', '$oddo', '$dopravniprostredek');";
	$this->db->query($query);
	}
        
        function saverecords2($id,$zdo,$cislo,$typ)
	{
	$query="INSERT INTO lety (id, zdo, cislo, typ) VALUES ('$id', '$zdo', '$cislo', '$typ');";
	$this->db->query($query);
	}
        
        function saverecords3($id,$nazev,$text)
	{
	$query="INSERT INTO denik (id, nazev, text) VALUES ('$id', '$nazev', '$text');";
	$this->db->query($query);
	}
}