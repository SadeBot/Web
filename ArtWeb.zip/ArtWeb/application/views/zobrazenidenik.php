
   <br> 
    <h2>Cestovatelské deníky:</h2>

    <div class="column">
            <div style="margin-top: 50px; background-color: white">
                <table class="table table-striped" style="" >
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Název</th>
                            <th>text</th>
                          
                        
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($data as $teple){
                            echo    "<tr>";
                            echo        "<td>", $teple->id, "</td>";
                            echo        "<td>", $teple->nazev, "</td>";
                            echo        "<td>", $teple->text, "</td>";
                       
                          
                           
                            echo    "</tr>";
                        }
                        ?>
       
                    </tbody>
                </table>                 
        
            </div>

    </div>
    

