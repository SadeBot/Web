<br>
<h3>Přidání letu:</h3>
    <br>
    <br>

<form method="post">
		<table width="600" cellspacing="5" cellpadding="5">
  <tr>
    <td width="230">ID: </td>
    <td width="329"><input type="number" name="id"/></td>
  </tr>
  <tr>
    <td>z destinace -> do destinace </td>
    <td><input type="text" name="zdo"/></td>
  </tr>
   <tr>
   <td>číslo letu </td>
    <td><input type="text" name="cislo"/></td>
  </tr>
   <tr>
    <td>typ letadla </td>
    <td><input type="text" name="typ"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="submit" class="btn btn-primary" name="save" value="Přidat do DB"/></td>
    
  </tr>
</table>

	</form>
    

</body>

</html>

