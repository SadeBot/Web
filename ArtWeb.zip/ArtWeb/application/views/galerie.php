<?php
?>
<center>
<div class="container">
    <div class="row">

<div  class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://storage.googleapis.com/businessinfo_cz/2019/12/f8fa6ac4-eiffelova-vez-pariz-francie-shutterstock_1041178405-scaled.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Francie</h4>
    
  </div>
</div>


<div  class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://d34-a.sdn.cz/d_34/c_B_C/rjEJdr.jpeg?fl=cro,0,120,1600,901|res,400,225,3" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Německo</h4>
    
  </div>
</div>



<div  class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://www.livingstone.cz/upload/responsive/kraken/info-o-zemich/asie/Japonsko-hlavicka-03.webp" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Japonsko</h4>
    
  </div>
</div>


<div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://slevomat.sgcdn.cz/images/t/728x364c/58/41/5841653-c25516.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Rakousko</h4>
    
  </div>
</div>

<div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://www.exclusivetours.com/uploaded/product/main_img/w1980/spanelsko-uvodni.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Španělsko</h4>
    
  </div>
</div>


 <div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://i.content4travel.com/cms/img/u/kraj/1/kuba_0.jpg?version=180331-08" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Kuba</h4>
    
  </div>
</div>

<div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://d15-a.sdn.cz/d_15/c_img_F_G/HpaSbF.jpeg?fl=cro,0,8,800,450%7Cres,1200,,1%7Cwebp,75" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">USA</h4>
    
  </div>
</div>
    
    <div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://d15-a.sdn.cz/d_15/c_img_F_G/sjcGFZ.jpeg?fl=cro,0,54,800,450%7Cres,1200,,1%7Cwebp,75" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Jamajka</h4>
    
  </div>
</div>
        
        <div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://cdn.travelpulse.com/images/54aaedf4-a957-df11-b491-006073e71405/ee952e9e-f09c-49c2-bc5d-4303c880173a/630x355.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Hawaii</h4>
    
  </div>
</div>

    
    
    
    
    
    
    
    
    </div>   
</div>
</center>