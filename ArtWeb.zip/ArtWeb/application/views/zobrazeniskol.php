<div class="container" >
   <br> 
    <h2>Seznam škol</h2>

    <div class="column">
            <div style="margin-top: 50px; background-color: white">
                <table class="table table-striped" style="" >
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nazev</th>
                            <th>mesto</th>
                           
                        
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($data as $skola){
                            echo    "<tr>";
                            echo        "<td>", $skola->id, "</td>";
                            echo        "<td>", $skola->nazev, "</td>";
                            echo        "<td>", $skola->nazevMesta, "</td>";
                           
                          
                           
                            echo    "</tr>";
                        }
                        ?>
       
                    </tbody>
                </table>                 
        
            </div>

    </div>
    
   
    <div id="mapid"></div>
    
    <br>
    <br>
    <br>
    
    
    
    
</div>



<style>#mapid { height: 500px; }</style>
<script>var mymap = L.map('mapid').setView([48.930711, 17.74298], 13);
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: 'pk.eyJ1IjoidG9tYXNobGFkaXMiLCJhIjoiY2tnZ2VqczJpMDA4bjJybndkZ2p6ODI5cSJ9.clPSCTZH6YetMmFCJY6tlA'
}).addTo(mymap);




</script>   


 <?php
                        foreach ($data as $skola){?>
                            <script>var marker = L.marker([<?php echo $skola->geolat?>, <?php echo $skola->geolong ?>]).addTo(mymap);
                                marker.bindPopup("<b><?php echo $skola->nazev?></b><br><?php echo $skola->nazevMesta?>");
                            </script><?php
}?>
