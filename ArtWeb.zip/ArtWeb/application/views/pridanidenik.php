<br>
<h3>Přidání nového cestovatelského deníku:</h3>
    <br>
    <br>

<form method="post">
		<table width="600" cellspacing="5" cellpadding="5">
  <tr>
    <td width="230">ID: </td>
    <td width="329"><input type="number" name="id"/></td>
  </tr>
  <tr>
    <td>Nazev deníku: </td>
    <td><input type="text" name="nazev"/></td>
  </tr>
   <tr>
   <td>text deníku </td>
    <td><input type="text" name="text"/></td>
  </tr>
    
  <tr>
    <td colspan="2" align="center"><input type="submit" class="btn btn-primary" name="save" value="Přidat do DB"/></td>
  </tr>
</table>

	</form>
    

</body>

</html>

