<div class="container bg-white" style="background-color: white">
   <br> 
    <h2>Seznam uskutečněných letů:</h2>

    <div class="column" style="background-color: white">
            <div style="margin-top: 50px; background-color: white">
                <table class="table table-striped" style="" >
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Z destinace - do destinace</th>
                            <th>Číslo letu</th>
                            <th>typ letadla</th>
                        
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($data as $lety){
                            echo    "<tr>";
                            echo        "<td>", $lety->id, "</td>";
                            echo        "<td>", $lety->zdo, "</td>";
                            echo        "<td>", $lety->cislo, "</td>";
                            echo        "<td>", $lety->typ, "</td>";
                        
                           
                            echo    "</tr>";
                        }
                        ?>
       
                    </tbody>
                </table>                 
        
            </div>

    </div>
    
</div>
