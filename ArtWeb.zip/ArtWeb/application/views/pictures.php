<?php

?>

<html>
    <head>
        <link href="https://bootswatch.com/4/lux/bootstrap.min.css" rel="stylesheet" type="text/css">
          <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>    
   
     <style>
            
                   nav {
  background-color: ;  
}
 a {
  color: ;  
}



        </style>
    
    
    
    
    
    
    
    </head>
    
    <body>    

         <div class="bg-light"  >
 
          <nav class="navbar navbar-expand-lg ">
  <a class="navbar-brand" color="red" href="<?php echo base_url();?>">Travel diary</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      
   
      
           
       <li class="nav-item active">
       <a class="nav-link" href="<?php echo base_url()?>index.php/zobrazeniskol">list of trips<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
           <a class="nav-link" href="<?php echo base_url()?>index.php/zobrazenilety">list of flights<span class="sr-only">(current)</span></a>
           </li>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo base_url()?>index.php/zobrazenidenik">diary<span class="sr-only">(current)</span></a>
           </li>
           <li class="nav-item active">
                <a class="nav-link" href="<?php echo base_url()?>index.php/galerie">pictures<span class="sr-only">(current)</span></a>
           </li>
           
           
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo base_url()?>index.php/galerie">  <img class="card-img-top" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Flag_of_the_Czech_Republic.svg/30px-Flag_of_the_Czech_Republic.svg.png" alt="Card image">           <span class="sr-only">(current)</span></a>
          
           
           
           </li>
           
           
           
      
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <a class="nav-link" href="<?php echo base_url();?>index.php/auth/login"><div class="">login for admin</div><span class="sr-only">(current)</span></a>
    </form>
      
  </div>
</nav>
        
          
            
         
         
         </div>
        
        
        
    
    
    
    
    
    <center>
<div class="container">
    <div class="row">

<div  class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://storage.googleapis.com/businessinfo_cz/2019/12/f8fa6ac4-eiffelova-vez-pariz-francie-shutterstock_1041178405-scaled.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">France</h4>
    
  </div>
</div>


<div  class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://d34-a.sdn.cz/d_34/c_B_C/rjEJdr.jpeg?fl=cro,0,120,1600,901|res,400,225,3" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Germamy</h4>
    
  </div>
</div>



<div  class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://www.livingstone.cz/upload/responsive/kraken/info-o-zemich/asie/Japonsko-hlavicka-03.webp" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Japan</h4>
    
  </div>
</div>


<div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://slevomat.sgcdn.cz/images/t/728x364c/58/41/5841653-c25516.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Austria</h4>
    
  </div>
</div>

<div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://www.exclusivetours.com/uploaded/product/main_img/w1980/spanelsko-uvodni.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Spain</h4>
    
  </div>
</div>


 <div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://i.content4travel.com/cms/img/u/kraj/1/kuba_0.jpg?version=180331-08" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Cuba</h4>
    
  </div>
</div>

<div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://d15-a.sdn.cz/d_15/c_img_F_G/HpaSbF.jpeg?fl=cro,0,8,800,450%7Cres,1200,,1%7Cwebp,75" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">USA</h4>
    
  </div>
</div>
    
    <div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://d15-a.sdn.cz/d_15/c_img_F_G/sjcGFZ.jpeg?fl=cro,0,54,800,450%7Cres,1200,,1%7Cwebp,75" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Jamaica</h4>
    
  </div>
</div>
        
        <div class="card col-lg-4 col-md-6" style="width:400px">
  <img class="card-img-top" src="https://cdn.travelpulse.com/images/54aaedf4-a957-df11-b491-006073e71405/ee952e9e-f09c-49c2-bc5d-4303c880173a/630x355.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Hawaii</h4>
    
  </div>
</div>

    
    
    
    
    
    
    
    
    </div>   
</div>
</center>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    </body>
    
    