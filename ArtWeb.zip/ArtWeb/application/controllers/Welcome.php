<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

        
        public function nacticesty()
        {
            $this->load->view('navbar');
            $this->load->view('navbarAdmin');
            $this->load->view('pridanicesty');
        }
         public function galerie()
        {
            $this->load->view('navbar');
            
            $this->load->view('galerie');
        }
        public function nactilety()
        {
            $this->load->view('navbar');
            $this->load->view('navbarAdmin');
            $this->load->view('pridaniNealka');
        }
        public function nactidenik()
        {
            
            $this->load->view('navbar');
            $this->load->view('navbarAdmin');
            $this->load->view('pridanidenik');
        }
        
        
        
        
        
        
        
        public function nactizobrazeniskol()
        {
           $this->load->model("model");
            $data["data"] = $this->model->get_cesty();
            $this->load->view('navbar');                      
            $this->load->view('zobrazeniskol', $data);
        }
        
        
        
        
        
        
        
        
        public function nactiZobrazenilety()
        {
           $this->load->model("model");
            $data["data"] = $this->model->get_lety();
            $this->load->view('navbar');                      
            $this->load->view('zobrazenilety', $data);
        }
        public function nactiZobrazenidenik()
        {
           $this->load->model("model");
            $data["data"] = $this->model->get_denik();
            $this->load->view('navbar');                      
            $this->load->view('zobrazenidenik', $data);
        }
 

        public function index()
	{
                $this->load->view('navbar');
                $this->load->view('hlavniStranka');
	}
        public function __construct()
	{
	//call CodeIgniter's default Constructor
	parent::__construct();
	
	//load database libray manually
	$this->load->database();
	
	//load Model
	$this->load->model('model');
	}
	public function savedata()
	{
            $this->load->database();
             $this->load->view('navbar');
             $this->load->view('navbarAdmin');
            $this->load->model("model");
		$this->load->view('pridanicesty');	

		if($this->input->post('save'))
		{

		$id=$this->input->post('id');
		$cil=$this->input->post('cil');
		$oddo=$this->input->post('oddo');
		$dopravniprostredek=$this->input->post('dopravniprostredek');
		
		$this->model->saverecords($id,$cil,$oddo,$dopravniprostredek);		
		echo '<div style="position:absolute; bottom:2px;">itwerks</div>';
		}
	}
        public function savedata2()
	{
            $this->load->database();
             $this->load->view('navbar');
             $this->load->view('navbarAdmin');
            $this->load->model("model");
		$this->load->view('pridanilety');	

		if($this->input->post('save'))
		{

		$id=$this->input->post('id');
		$zdo=$this->input->post('zdo');
		$cislo=$this->input->post('cislo');
		$typ=$this->input->post('typ');
		
		$this->model->saverecords2($id,$zdo,$cislo,$typ);		
		echo '<div style="position:absolute; bottom:2px;">itwerks</div>';
		}
	}
        public function savedata3()
	{
            $this->load->database();
             $this->load->view('navbar');
             $this->load->view('navbarAdmin');
            $this->load->model("model");
		$this->load->view('pridanidenik');	

		if($this->input->post('save'))
		{

		$id=$this->input->post('id');
		$nazev=$this->input->post('nazev');
		$text=$this->input->post('text');
		
		
		$this->model->saverecords3($id,$nazev,$text);		
		echo '<div style="position:absolute; bottom:2px;">itwerks</div>';
		}
	}
        
    
        
        
        
        
        public function pictures()
        {
            
           
            $this->load->view('pictures');
        }
        
        
        
        
        
        
        

 }

